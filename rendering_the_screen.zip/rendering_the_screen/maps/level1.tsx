<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="level1" tilewidth="128" tileheight="128" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="128" height="128" source="../../../../Desktop/platform_tutorial/platform_tutorial/images/tiles/cactus.png"/>
 </tile>
</tileset>
